import java.util.*;

public class pointTester 
{

	public static void main(String[] args) 
	{
		point p1 = new point();
		point p2 = new point(3.0, 4.0);
	}

}
