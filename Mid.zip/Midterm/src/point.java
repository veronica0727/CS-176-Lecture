import java.util.*;

public class point 
{
	private double x;
	private double y;
	
	public point (double initalX, double initalY)
	{
		this.x = initalX;
		this.y = initalY;
	}
	
	public point()
	{
		this.x = 0.0;
		this.y = 0.0;
	}
	
	public double getX ()
	{
		return this.x;
	}
	
	public double getY ()
	{
		return this.y;
	}
	
	public void setX (double newX)
	{
		this.x = newX;
	}
	
	public void setY (double newY)
	{
		this.y = newY;
	}
	
	public double computeDistance (point p)
	{
		double currentX = x;
		double currentY = y;
		
		double anotherX = p.getX();
		double anotherY = p.getY();
		
		double distance  = Math.sqrt((currentX - anotherX) * (currentX - anotherX) + (currentY - anotherY));
		return distance;
	}
	public String toString()
	{
		return "(" + x + "," + y + ")";
	}
}
