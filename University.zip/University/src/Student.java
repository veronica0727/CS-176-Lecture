import java.util.*;
public class Student 
{
	private String name;
	private String id;
	private double gpa;
	private ArrayList<Course> courses = new ArrayList<Course>();
	
	public  Student (String sname, String sID, double sGPA, ArrayList<Course> sCourses)
	{
		this.name = sname;
		this.id = sID;
		this.gpa = sGPA;
		this.courses = sCourses;
	}
	
	public Student (String sname, String sID)
	{
		this.name = sname;
		this.id = sID;
	}
	
	public String toString ()
	{
		return 
				"Name: " + name + "\n" +
				"ID: " + id + "\n" +
				"GPA: " + gpa + "\n" +
				"Courses: " + courses;
	}
	
	public String getName()
	{
		return 
				this.name;
	}
	
	public String getID()
	{
		return 
				this.id;
	}
	
	public double getGPA()
	{
		return
				this.gpa;
	}
	
	public ArrayList<Course> getCourses()
	{
		return 
				this.courses;
	}
	
	public void setName (String sName)
	{
		this.name = sName;
	}
	
	public void setID (String sID)
	{
		this.id = sID;
	}
	
	public void computeGPA ()
	{
		double sum = 0;
		int counter = 0;
		for (Course sCourse: courses)
		{	
			if (sCourse.getGrade() >= 0)
			{
				sum = sum + sCourse.getGrade();
				counter = counter+1;
			
			}
		}
		gpa = sum /counter;
	}
	
	public void register(String sCourse)
	{
		Course newCourse = new Course (sCourse);
		courses.add(newCourse);
	}
	
	public void grade(double sGrade, String sCourseName)
	{
		for (Course sCourse : courses)
		{
			if(sCourse.getCourse().contentEquals(sCourseName)&& sCourse.getGrade()<0)
			{
				sCourse.setGrade(sGrade);
			}
		}
	}
}
