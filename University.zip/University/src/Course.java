import java.util.*;
public class Course 
{
	private String name;
	private double grade;
	
	public Course(String cname, double cgrade)
	{
		this.name = cname;
		this.grade = cgrade;
	}
	
	public Course (String cname)
	{
		this.name = cname;
		this.grade = -1;
	}
	
	public String getCourse()
	{
		return this.name;
	}
	
	public void setCourse(String cname)
	{
		this.name = cname;
	}
	
	public double getGrade()
	{
		return this.grade;
	}
	
	public void setGrade(double cgrade)
	{
		this.grade = cgrade;
	}
	
	public String toString()
	{
		if (grade < 0) 
			return "Course Name: " + name + "Grade: ";
		else 
			return 
				"Course Name : " + name + " " +
				"Grade: " + grade ;
	}
	
	

}
