import java.util.*;
public class StudentTester 
{

	public static void main(String[] args) 
	{
		Student Tom = new Student ("Tom", "123456");
		System.out.println("Student Name: " + Tom.getName());
		System.out.println("Student ID: " + Tom.getID());
		
		ArrayList<Course> bCourses = new ArrayList<Course> ();
		Course cs175 = new Course ("CS175", 90);
		bCourses.add(cs175);
		Course ma125 = new Course ("MA125", 90);
		bCourses.add(ma125);
		
		Student Bob = new Student ("Bob", "234567", 90, bCourses );
		System.out.println("Transfer Student Name: " + Bob.getName());
		System.out.println("Student ID: " + Bob.getID());
		System.out.println("Student Courses: " + Bob.getCourses());
	}

}
