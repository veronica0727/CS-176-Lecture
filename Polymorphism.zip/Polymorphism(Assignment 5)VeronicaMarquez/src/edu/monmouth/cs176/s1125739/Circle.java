package edu.monmouth.cs176.s1125739;
import java.util.*;


public class Circle extends Shape implements Comparable, Moveable
{
	
	private double x;
	private double y;
	private double radius;
	
	public Circle(String cColor, double x, double y, double radius)
	{
		super(cColor);
		this.x = x;
		this.y = y;
		this.radius = radius;
		
	}
	
	public void setRadius(int newRadius)
	{
		radius = newRadius;
	}
	public double getRadius()
	{
		return this.radius;
	}
	
	public void setX(int newX)
	{
		x = newX;
	}
	public double getX()
	{
		return this.x;
	}

	public void setY(double newY)
	{
		y = newY;
	}
	public double getY()
	{
		return this.y;
	}
	@Override 
	public double getArea()
	{
		return 
				 Math.PI * radius * radius;
		
	}
	
	
	
	  public boolean equals(Object obj)
	  {
		  if(obj instanceof Circle)
		  {
			  Circle c = (Circle) obj;
			  if(radius == (c.radius)&& x ==(c.x) && y == (c.y) )
			  {
				  return true;
			  }else return false;
		  }else return false;
	  }
	
	@Override
	public String toString()
	{
		return 
				super.toString() + "\n" +
				"Center (x,y): (" + x + "," + y + ")" + "\n" +
				"Radius: " + radius  ;
	}

	//Interface
	public int compareTo(Object obj) 
	{
		Circle otherCircle = (Circle) obj;
		if(radius > otherCircle.radius)
			return 1;
		else if(radius == otherCircle.radius)
			return 0;
		else return -1;
	}

	@Override
	public void move(double detlax, double detlay) 
	{
		x = this.x + detlax;
		y = this.y + detlay;
		
		
	}
	
}
