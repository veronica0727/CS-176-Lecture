package edu.monmouth.cs176.s1125739;

import java.util.Arrays;

public class ShapeTester {

	public static void main(String[] args)
	{
		/*Shape[] shape = new Shape[6];
		
		shape[0] = new Circle("Red Circle", 0.0, 1.0, 2.0);
		Circle circle1 = (Circle)shape[0];
		shape[1] = new Circle("Blue Circle", 1.0, 2.0, 2.0);
		Circle circle2 = (Circle) shape[1];
		shape[2] = new Rectangle("Green Rectangle", 5.0, 10.0, 20.0, 10.0);
		Rectangle rectangle = (Rectangle) shape[2];
		shape[3] = new Triangle("Yellow Triangle " , 3.0,4.0,5.0);
		Triangle triangle = (Triangle) shape[3];
		shape[4] = new Sphere("Pink Sphere", 1.0, 1.0, 1.0, 4.0);
		Sphere sphere = (Sphere) shape[4];
		shape[5] = new Cubiod("Orange Cubiod" , 0.0, 5.0, 10.0, 10.0, 5.0, 4.0);
		Cubiod cubiod = (Cubiod) shape[5];
		
		//Loop to print out the array, calculate and print each shape's area
		 for ( int i = 0; i < shape.length; i++ ) 
		 {
	         System.out.println(shape[i].toString());
	         System.out.println("Area = " + shape[i].getArea());
	         System.out.println();
		 }
		 
		 //Calculate and print the sphere's volume
		 System.out.println(sphere.toString() + "\nVolume: " + sphere.getVolume());
		 
		 System.out.println();
		 
		 //Calculate and print the cubiod volume
		 System.out.println(cubiod.toString() + "\nVolume: " + cubiod.getVolume());
		 
		 System.out.println();
		 
		 //Change 1st circle center to (1,2) and check
		 circle1.setX(1);
		 circle1.setY(2);
		 System.out.println("Circle 1 = Circle 2? " + circle1.equals(circle2));
		 
		 System.out.println();
		 
		 //Change rectangle width to 15, recalcualte and print its area
		 rectangle.setWidth(15);
		 System.out.println("Rectangle new Area: " + rectangle.getArea());*/
		
		
		Circle[] circle = new Circle [3];
		circle[0] = new Circle ("Yellow Circle", 0.0, 1.0, 2.0);
		circle[1] = new Circle("Orange Circle" , 3.0, 2.0, 4.0);
		circle[2] = new Circle("Red Circle", 4.0, 5.0, 1.0);
		
		//Create a new center for Circle 1
		circle[0].move(3, 1);
		System.out.println("\nCircle new center is: " + circle[0]);
		
		//sorts the array of Circles
				Arrays.sort(circle);
				System.out.print("\nSorted Circles" + ": ");
				for(int i = 0; i<circle.length; i++)
				{
					System.out.println("\n" + circle[i]);
				}
				
		Rectangle[] rec = new Rectangle[3];
		rec[0] = new Rectangle("Pink Rectangle", 5.0,10.0,20.0,3.0);
		rec[1] = new Rectangle("Blue Rectangle", 4.0,8.0,5.0,2.0);
		rec[2] = new Rectangle("Green Rectangle", 6.0,9.0,8.0,10.0);
		
		//moved Rectangle 2 units
		rec[1].move(2, 3);
		System.out.println("\nRectangle 2 moved (2,3) is now: " + rec[1]);
		
		//sorts the array of Rectangles
		Arrays.sort(rec);
		System.out.print("\nSorted Rectangles: ");
		for(int i = 0; i<rec.length; i++)
		{
			System.out.println("\n" + rec[i]);
		}
		
		//Created 2 Cuboid and compared them
		Cubiod cube1 = new Cubiod ("Purple Cuboid", 5.0,10.0,2.0, 20.0,3.0,2.0);
		Cubiod cube2 = new Cubiod ("Black Cuboid", 4.0,8.0,6.0, 5.0,2.0,10.0);
		
		System.out.println("\nthe cuboid with the largest volume is: " + cube1.compareTo(cube2));
		 
		
		
	}

	

}
