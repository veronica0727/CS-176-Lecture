package edu.monmouth.cs176.s1125739;

public class Triangle extends Shape
{
	private double s1Length;
	private double s2Length;
	private double s3Length;
	
	public Triangle(String tColor, double s1Length, double s2Length, double s3Length)
	{
		super(tColor);
		this.s1Length = s1Length;
		this.s2Length = s2Length;
		this.s3Length = s3Length;
	}
	
	@Override
	public double getArea()
	{
		double s = (s1Length + s2Length + s3Length)/2;
		return 
				Math.sqrt(s*(s-s1Length)*(s-s2Length)*(s-s3Length));
	}
	
	@Override
	public String toString()
	{
		return 
				super.toString() + "\n" + 
				"Sides: " + s1Length + "," + s2Length + "," + s3Length ;
				
	}
}
