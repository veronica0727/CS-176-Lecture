package edu.monmouth.cs176.s1125739;
import java.util.*;
public class Cubiod extends Rectangle 
{
	private double z;
	private double height;

	public Cubiod(String cuColor, double x, double y, double z,  double length, double width, double height) 
	{
		super(cuColor, x, y, length, width);
		this.z = z;
		this.height = height;
	}
	
	public double getZ()
	{
		return z;
	}
	public void setZ(double newZ)
	{
		z = newZ;
	}
	
	public double height()
	{
		return height;
	}
	public void setHeight(double newHeight)
	{
		height = newHeight;
	}
	
	@Override
	public double getArea()
	{
		return (2*((getLength() * getWidth())) + (getLength() * height) + (getLength() * height)  );
				
	}
	
	public double getVolume()
	{
		return (getLength() * getWidth() * height);
	} 
	
	public String toString()
	{
		return 
				super.toString() + "\n" + "Height: " + height;
	}
	
	@Override
	public int compareTo(Object obj)
	{
		Cubiod otherCubiod = (Cubiod) obj;
		if(getVolume() > otherCubiod.getVolume())
			return 1;
		else if(getVolume() == otherCubiod.getVolume())
			return 0;
		else return -1;
	}

	

}
