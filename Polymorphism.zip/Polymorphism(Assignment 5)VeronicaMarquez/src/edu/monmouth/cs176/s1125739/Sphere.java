package edu.monmouth.cs176.s1125739;
import java.util.*;
public class Sphere extends Circle 
{
	private double z;
	
	public Sphere(String SColor, double x, double y, double z, double sRadius)
	{
		super(SColor, x, y, sRadius);
		this.z = z;	
		
	}
	
	public double getZ()
	{
		return this.z;
	}
	public void setZ(double newZ)
	{
		z = newZ;
	}
	
	@Override
	public double getArea()
	{
		return 
				(4 * Math.PI * getRadius() * getRadius());
	}
	
	public double getVolume()
	{
		return ((4/3) * Math.PI * getRadius() * getRadius() * getRadius()); 
	}
	
	@Override
	public String toString()
	{
		return 
				
				"Center (x,y,z): (" + getX() + "," + getY() + "," + z + ")" + "\n" +
				"Radius: " + getRadius() ;
	}
}
