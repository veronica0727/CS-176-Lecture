package edu.monmouth.cs176.s1125739;
import java.util.*;

public class Shape 
{
	private String color;
	private double area;
	
	public Shape(String color)
	{
		this.color = color;
	}
	
	public double getArea()
	{
		return  0.0;
				
	}
	
	public String toString()
	{
		return 
				"Color: " + color;
	}
}
