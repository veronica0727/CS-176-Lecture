package edu.monmouth.cs176.s1125739;

public class Rectangle extends Shape implements Comparable, Moveable
{
	private double x;
	private double y;
	private double length;
	private double width;
	
	public Rectangle(String rColor, double x, double y, double length, double width)
	{
		super(rColor);
		this.x = x;
		this.y = y;
		this.length = length;
		this.width = width;
	}
	
	public double getLength()
	{
		return 
				this.length;
	}
	public void setLength(double newLength)
	{
		length = newLength;
	}
	
	public double getWidth()
	{
		return 
				this.width;			
	}
	public void setWidth(double newWidth)
	{
		width = newWidth;
	}
	
	@Override
	public double getArea()
	{
		return 
				 length * width;
	}
	
	@Override
	public String toString()
	{
		return
				super.toString()+  "\n" +
				"top-left-corner (x,y): (" + x + "," + y + ")" + "\n" + 
				"Length: " + length + "\n" +
				"Width: " + width  ;
	}

	//Interface
	public int compareTo(Object obj)
	{
		Rectangle otherRectangle = (Rectangle) obj;
		if(getArea() > otherRectangle.getArea())
			return 1;
		else if(getArea() == otherRectangle.getArea())
			return 0;
		else return -1;
	}

	@Override
	public void move(double detlax, double detlay) 
	{
		x = this.x + detlax;
		y = this.y + detlay;
		
	}
}
