package edu.monmouth.cs176.s1125739;

public interface Moveable
{
	void move(double detlax, double detlay);
}
